@echo off
setlocal EnableExtensions EnableDelayedExpansion
set "OUT=%~1"
if "%OUT%"=="" exit /b 1

for /L %%I in (1,1,120) do (
  if exist "%OUT%\STOP" exit /b 0

  >>"%OUT%\timeline_tasklist.txt" echo ===== SAMPLE %%I  %date% %time% =====
  tasklist /v >>"%OUT%\timeline_tasklist.txt" 2>&1

  set /a MOD=%%I%%5
  if !MOD! EQU 0 (
    >>"%OUT%\timeline_services.txt" echo ===== SAMPLE %%I  %date% %time% =====
    sc query type= service state= all >>"%OUT%\timeline_services.txt" 2>&1

    >>"%OUT%\timeline_netstat.txt" echo ===== SAMPLE %%I  %date% %time% =====
    netstat -ano >>"%OUT%\timeline_netstat.txt" 2>&1
  )

  ping 127.0.0.1 -n 2 >nul
)
exit /b 0
