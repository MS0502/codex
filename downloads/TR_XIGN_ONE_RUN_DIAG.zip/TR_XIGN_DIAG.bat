@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"

set "OUT=%~dp0TR_XIGN_DIAG_OUT"
if exist "%OUT%" rmdir /s /q "%OUT%"
mkdir "%OUT%"

echo TalesRunner / XIGNCODE diagnostic capture
echo Output: "%OUT%"
echo.

if not exist "%~dp0TR_LOGIN_AND_RUN_FIXED.bat" (
  echo ERROR: TR_LOGIN_AND_RUN_FIXED.bat was not found beside this file.
  echo Put this diagnostic file in D:\TR_KR_LOCAL and run it again.
  pause
  exit /b 1
)

(
  echo ===== BASIC =====
  echo DATE=%date%
  echo TIME=%time%
  ver
  echo PROCESSOR_ARCHITECTURE=%PROCESSOR_ARCHITECTURE%
  echo PROCESSOR_IDENTIFIER=%PROCESSOR_IDENTIFIER%
  echo NUMBER_OF_PROCESSORS=%NUMBER_OF_PROCESSORS%
  echo TEMP=%TEMP%
  echo TMP=%TMP%
  echo CD=%CD%
) > "%OUT%\basic.txt" 2>&1

whoami /all > "%OUT%\whoami.txt" 2>&1
tasklist /v > "%OUT%\tasklist_before.txt" 2>&1
tasklist /m > "%OUT%\modules_before.txt" 2>&1
sc query type= service state= all > "%OUT%\services_before.txt" 2>&1
driverquery /v > "%OUT%\drivers_before.txt" 2>&1
netstat -ano > "%OUT%\netstat_before.txt" 2>&1
reg query "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion" > "%OUT%\windows_version_registry.txt" 2>&1
reg query "HKCU\Software\Wine" /s > "%OUT%\wine_registry_hkcu.txt" 2>&1
reg query "HKLM\Software\Wine" /s > "%OUT%\wine_registry_hklm.txt" 2>&1
reg query "HKLM\SYSTEM\CurrentControlSet\Services" /s > "%OUT%\services_registry_all.txt" 2>&1
findstr /i /c:"xign" /c:"xldr" /c:"xxd" /c:"xhunter" "%OUT%\services_registry_all.txt" > "%OUT%\services_registry_xign_matches.txt" 2>&1

dir /s /a "%~dp0" > "%OUT%\game_tree.txt" 2>&1
if exist "%TEMP%" dir /s /a "%TEMP%" > "%OUT%\temp_tree_before.txt" 2>&1

(
  echo ===== XIGN / XLDR / SYS FILES =====
  for /r "%~dp0" %%F in (*.sys) do echo %%~fF ^| %%~zF bytes ^| %%~tF
  for /r "%~dp0" %%F in (*xign*) do echo %%~fF ^| %%~zF bytes ^| %%~tF
  for /r "%~dp0" %%F in (*xldr*) do echo %%~fF ^| %%~zF bytes ^| %%~tF
  for /r "%~dp0" %%F in (*xxd*) do echo %%~fF ^| %%~zF bytes ^| %%~tF
) > "%OUT%\suspect_files.txt" 2>&1

start "" /min cmd.exe /d /q /c ""%~dp0TR_XIGN_WATCH.bat" "%OUT%""

echo.
echo Starting the official fixed launcher.
echo When E0190204 appears:
echo   1. Take a screenshot.
echo   2. Close the XIGNCODE error window.
echo   3. Return to this console and press a key if the launcher asks.
echo.
call "%~dp0TR_LOGIN_AND_RUN_FIXED.bat"

> "%OUT%\STOP" echo stop
ping 127.0.0.1 -n 3 >nul

tasklist /v > "%OUT%\tasklist_after.txt" 2>&1
tasklist /m > "%OUT%\modules_after.txt" 2>&1
sc query type= service state= all > "%OUT%\services_after.txt" 2>&1
driverquery /v > "%OUT%\drivers_after.txt" 2>&1
netstat -ano > "%OUT%\netstat_after.txt" 2>&1
reg query "HKLM\SYSTEM\CurrentControlSet\Services" /s > "%OUT%\services_registry_after.txt" 2>&1
findstr /i /c:"xign" /c:"xldr" /c:"xxd" /c:"xhunter" "%OUT%\services_registry_after.txt" > "%OUT%\services_registry_xign_matches_after.txt" 2>&1
if exist "%TEMP%" dir /s /a "%TEMP%" > "%OUT%\temp_tree_after.txt" 2>&1

(
  echo Capture completed.
  echo DATE=%date%
  echo TIME=%time%
) > "%OUT%\DONE.txt"

echo.
echo Capture complete.
echo Folder:
echo   %OUT%
echo.
echo Also collect:
echo   Documents\Winlator\logs.txt
echo Then sanitize that log in Termux before uploading.
pause
endlocal
