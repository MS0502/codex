TalesRunner / XIGNCODE one-run diagnostic bundle

1. Put TR_XIGN_DIAG.bat and TR_XIGN_WATCH.bat beside:
   TR_LOGIN_AND_RUN_FIXED.bat
   Usually: D:\TR_KR_LOCAL

2. In Winlator:
   Windows 10
   Startup Essential
   Box64 Intermediate
   WINEESYNC ON
   Enable Wine Debug ON
   Wine debug channels: warn, err, fixme
   Save logs to file ON
   Box64 logs: lowest enabled level

3. Run TR_XIGN_DIAG.bat.
   When E0190204 appears, screenshot it, close it, then press a key in the
   launcher console if requested.

4. Collect:
   D:\TR_KR_LOCAL\TR_XIGN_DIAG_OUT
   Documents\Winlator\logs.txt

5. Sanitize the Winlator log in Termux:
   python ~/storage/downloads/SANITIZE_WINLATOR_LOG.py      ~/storage/shared/Documents/Winlator/logs.txt

6. Upload:
   - TR_XIGN_DIAG_OUT folder as ZIP
   - logs_sanitized.txt
   - the E0190204 screenshot

Do not upload token files, TR_AUTH_STATUS.json, or raw unsanitized logs.
