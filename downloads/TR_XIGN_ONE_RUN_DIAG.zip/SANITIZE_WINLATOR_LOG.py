#!/usr/bin/env python3
from __future__ import annotations

import re
import sys
from pathlib import Path

PATTERNS: list[tuple[re.Pattern[str], str]] = [
    # Authorization headers
    (re.compile(r"(?i)(authorization\s*:\s*bearer\s+)[^\s\"']+"), r"\1[REDACTED]"),
    # Query-string / key-value tokens
    (re.compile(r"(?i)\b(access[_-]?token|auth[_-]?token|refresh[_-]?token|token|jwt|jwe)\b(\s*[:=]\s*|%3[dD])([^\s&\"']+)"),
     r"\1\2[REDACTED]"),
    # Common command-line forms: --token VALUE, /token:VALUE, -auth VALUE
    (re.compile(r"(?i)(?:--?|/)(access[_-]?token|auth[_-]?token|refresh[_-]?token|token|jwt|jwe)(?:\s+|[:=])([^\s\"']+)"),
     r"--\1 [REDACTED]"),
    # JWE: five base64url segments
    (re.compile(r"(?<![A-Za-z0-9_-])(?:[A-Za-z0-9_-]{8,}\.){4}[A-Za-z0-9_-]{8,}(?![A-Za-z0-9_-])"),
     "[REDACTED_JWE]"),
    # JWT: three base64url segments
    (re.compile(r"(?<![A-Za-z0-9_-])[A-Za-z0-9_-]{12,}\.[A-Za-z0-9_-]{12,}\.[A-Za-z0-9_-]{12,}(?![A-Za-z0-9_-])"),
     "[REDACTED_JWT]"),
]

def sanitize(text: str) -> str:
    for pattern, replacement in PATTERNS:
        text = pattern.sub(replacement, text)
    return text

def main() -> int:
    if len(sys.argv) not in (2, 3):
        print("Usage: python SANITIZE_WINLATOR_LOG.py INPUT_LOG [OUTPUT_LOG]")
        return 2

    src = Path(sys.argv[1]).expanduser()
    if not src.is_file():
        print(f"ERROR: file not found: {src}")
        return 1

    dst = Path(sys.argv[2]).expanduser() if len(sys.argv) == 3 else src.with_name(src.stem + "_sanitized" + src.suffix)

    raw = src.read_text(encoding="utf-8", errors="replace")
    cleaned = sanitize(raw)
    dst.write_text(cleaned, encoding="utf-8")

    print(f"Sanitized log written to: {dst}")
    print(f"Input chars: {len(raw)}")
    print(f"Output chars: {len(cleaned)}")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
